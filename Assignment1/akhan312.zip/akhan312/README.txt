My code complete runs on python and used python libraries.  The best way to setup the environment for to execute the code is as follows:

Install Anaconda with 2.7 python

install pybrain using instructions from http://pybrain.org/docs/quickstart/installation.html