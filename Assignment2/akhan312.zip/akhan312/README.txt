My code complete runs on python and uses the anaconda 2.7 package of python.   Additionally it depends on Pybrain for the neural network constructions..  The best way to setup the environment for to execute the code is as follows:

Install Anaconda with 2.7 python

install pybrain using instructions from http://pybrain.org/docs/quickstart/installation.html

You can then execute the individual python files:

akhan312_BackProp_NN_Final.py
akhan312_RHC_NN_Final.py
akhan312_SA_NN_FInal.py
akhan312_GA_NN_Final.py